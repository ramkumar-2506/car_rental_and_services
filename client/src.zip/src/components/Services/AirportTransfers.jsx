import { Link } from "react-router-dom";
import Button from "../Common/Button";

const AirportTransfers = () => {
  return (
    <section className="py-12 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <div className="max-w-2xl">
          <span className="inline-block px-3 py-1 rounded-full bg-gray-100 text-sm font-semibold text-gray-700">
            Airport Transfers
          </span>
          <h2 className="mt-4 text-3xl font-bold text-gray-900">Comfortable rides to and from the airport</h2>
          <p className="mt-3 text-gray-600">
            Pre-book your transfer and reach your destination on time with professional support.
          </p>
        </div>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { title: "On-time Pickup", desc: "We track flight timing and plan accordingly." },
            { title: "Professional Drivers", desc: "Verified and courteous chauffeurs." },
            { title: "Easy Booking", desc: "Pick dates, choose options, confirm quickly." },
          ].map((x) => (
            <div key={x.title} className="border rounded-xl p-6 shadow-sm bg-gray-50">
              <h3 className="font-semibold text-gray-900">{x.title}</h3>
              <p className="mt-2 text-gray-600">{x.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-10 flex items-center gap-4">
          <Link to="/booking">
            <Button text="Book Airport Transfer" variant="primary" />
          </Link>
        </div>
      </div>
    </section>
  );
};

export default AirportTransfers;

