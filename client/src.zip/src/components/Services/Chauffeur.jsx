import {
  FaUserTie,
  FaStar,
  FaShieldAlt,
  FaClock,
  FaCheckCircle,
  FaArrowRight,
} from "../Icons/FaFallback";





const chauffeurs = [
  {
    id: 1,
    name: "Arun Kumar",
    experience: "8+ Years Experience",
    rating: "4.9",
    image:
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43?auto=format&fit=crop&w=900&q=80",
    languages: "English • Tamil • Hindi",
    availability: "Available 24/7",

    skills: [
      "Professional Driving",
      "Luxury Vehicle Expert",
      "Airport Transfers",
      "City Tours",
    ],
  },

  {
    id: 2,
    name: "Vignesh Raj",
    experience: "10+ Years Experience",
    rating: "4.8",
    image:
      "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=900&q=80",
    languages: "English • Tamil",
    availability: "Available Today",

    skills: [
      "Corporate Travel",
      "Business Meetings",
      "Long Distance Trips",
      "Premium Service",
    ],
  },

  {
    id: 3,
    name: "Rahul Sharma",
    experience: "12+ Years Experience",
    rating: "5.0",
    image:
      "https://images.unsplash.com/photo-1504593811423-6dd665756598?auto=format&fit=crop&w=900&q=80",
    languages: "English • Hindi",

    availability: "Available 24/7",

    skills: [
      "VIP Chauffeur",
      "Luxury Fleet",
      "Wedding Events",
      "Executive Travel",
    ],
  },
];

const Chauffeur = () => {
  return (
    <section className="chauffeur-section">

      <div className="chauffeur-container">

        <div className="chauffeur-header">

          <span className="section-tag">
            Professional Chauffeurs
          </span>

          <h2>
            Sit Back & Enjoy Your Journey
          </h2>

          <p>
            Hire experienced, licensed, and verified
            chauffeurs for business trips, family
            travel, airport transfers, weddings, and
            special occasions.
          </p>

        </div>

        <div className="chauffeur-grid">

          {chauffeurs.map((driver) => (

            <div
              className="chauffeur-card"
              key={driver.id}
            >

              <div className="driver-image">

                <img
                  src={driver.image}
                  alt={driver.name}
                />

                <span className="rating">

                  <FaStar />

                  {driver.rating}

                </span>

              </div>

              <div className="driver-content">

                <h3>{driver.name}</h3>

                <div className="driver-info">

                  <div>

                    <FaUserTie />

                    <span>
                      {driver.experience}
                    </span>

                  </div>

                  <div>

                    <FaClock />

                    <span>
                      {driver.availability}
                    </span>

                  </div>

                  <div>

                    <FaShieldAlt />

                    <span>
                      {driver.languages}
                    </span>

                  </div>

                </div>

                <div className="driver-skills">

                  {driver.skills.map(
                    (skill, index) => (

                      <div
                        className="skill"
                        key={index}
                      >

                        <FaCheckCircle />

                        <span>{skill}</span>

                      </div>

                    )
                  )}

                </div>
                                <div className="driver-actions">

                  <button className="hire-btn">
                    Hire Chauffeur
                    <FaArrowRight />
                  </button>

                  <button className="profile-btn">
                    View Profile
                  </button>

                </div>

              </div>

            </div>

          ))}

        </div>

        {/* =====================================
            WHY CHOOSE OUR CHAUFFEURS
        ===================================== */}

        <div className="chauffeur-benefits">

          <div className="benefit-card">

            <FaShieldAlt />

            <h4>Verified & Licensed</h4>

            <p>
              Every chauffeur is background verified,
              professionally trained, and holds a
              valid commercial driving license.
            </p>

          </div>

          <div className="benefit-card">

            <FaClock />

            <h4>Always On Time</h4>

            <p>
              Our drivers value punctuality, ensuring
              timely pickups and smooth travel for
              business meetings, airport transfers,
              and special occasions.
            </p>

          </div>

          <div className="benefit-card">

            <FaStar />

            <h4>Premium Customer Service</h4>

            <p>
              Enjoy courteous, experienced chauffeurs
              who prioritize your comfort, safety,
              and overall travel experience.
            </p>

          </div>

        </div>

      </div>

    </section>
  );
};

export default Chauffeur;