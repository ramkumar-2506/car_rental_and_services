import {
  FaBuilding,
  FaUsers,
  FaCarSide,
  FaShieldAlt,
  FaCheckCircle,
  FaArrowRight,
} from "../Icons/FaFallback";


const corporatePlans = [
  {
    id: 1,
    title: "Startup Plan",
    image:
      "https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=1200&q=80",

    price: "₹24,999",

    duration: "/Month",

    suitable: "Up to 10 Employees",

    vehicles: "2 Dedicated Vehicles",

    support: "Business Hour Support",

    features: [
      "Dedicated Account Manager",
      "Monthly Billing",
      "Employee Pick-up & Drop",
      "GPS Tracking",
    ],
  },

  {
    id: 2,
    title: "Business Plan",
    image:
      "https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&w=1200&q=80",

    price: "₹49,999",

    duration: "/Month",

    suitable: "Up to 50 Employees",

    vehicles: "5 Dedicated Vehicles",

    support: "24/7 Support",

    features: [
      "Priority Booking",
      "Airport Transfers",
      "Executive Cars",
      "Weekly Reports",
    ],
  },

  {
    id: 3,
    title: "Enterprise Plan",
    image:
      "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=80",

    price: "Custom",

    duration: "Pricing",

    suitable: "Unlimited Employees",

    vehicles: "Unlimited Fleet",

    support: "Dedicated Team",

    features: [
      "Custom Fleet Management",
      "24/7 Operations",
      "Premium Chauffeurs",
      "Custom Reporting",
    ],
  },
];

const CorporatePackages = () => {
  return (
    <section className="corporate-section">

      <div className="corporate-container">

        <div className="corporate-header">

          <span className="section-tag">
            Corporate Solutions
          </span>

          <h2>
            Corporate Travel Made Simple
          </h2>

          <p>
            We provide reliable transportation
            solutions for startups, businesses,
            and large enterprises with flexible
            fleet management and dedicated support.
          </p>

        </div>

        <div className="corporate-grid">

          {corporatePlans.map((plan) => (

            <div
              className="corporate-card"
              key={plan.id}
            >

              <div className="corporate-image">

                <img
                  src={plan.image}
                  alt={plan.title}
                />

                <span className="corporate-badge">
                  {plan.suitable}
                </span>

              </div>

              <div className="corporate-content">

                <h3>{plan.title}</h3>

                <div className="corporate-price">

                  <h2>{plan.price}</h2>

                  <span>{plan.duration}</span>

                </div>

                <div className="corporate-info">

                  <div>

                    <FaBuilding />

                    <span>
                      {plan.vehicles}
                    </span>

                  </div>

                  <div>

                    <FaUsers />

                    <span>
                      {plan.suitable}
                    </span>

                  </div>

                  <div>

                    <FaShieldAlt />

                    <span>
                      {plan.support}
                    </span>

                  </div>

                </div>

                <div className="corporate-features">

                  {plan.features.map(
                    (feature, index) => (

                      <div
                        className="feature"
                        key={index}
                      >

                        <FaCheckCircle />

                        <span>{feature}</span>

                      </div>

                    )
                  )}

                </div>
                                <div className="corporate-actions">

                  <button className="contact-btn">
                    Contact Sales
                    <FaArrowRight />
                  </button>

                  <button className="learn-btn">
                    Learn More
                  </button>

                </div>

              </div>

            </div>

          ))}

        </div>

        {/* =====================================
            WHY CHOOSE CORPORATE PACKAGES
        ===================================== */}

        <div className="corporate-benefits">

          <div className="benefit-card">

            <FaCarSide />

            <h4>Dedicated Fleet</h4>

            <p>
              Access a fleet of professionally maintained
              vehicles reserved exclusively for your
              organization to ensure reliable daily
              transportation.
            </p>

          </div>

          <div className="benefit-card">

            <FaUsers />

            <h4>Employee Transportation</h4>

            <p>
              Simplify employee commuting with scheduled
              pick-up and drop services, airport transfers,
              and business travel solutions.
            </p>

          </div>

          <div className="benefit-card">

            <FaShieldAlt />

            <h4>Reliable Business Support</h4>

            <p>
              Benefit from dedicated account managers,
              priority customer support, transparent
              billing, and customized travel reports.
            </p>

          </div>

        </div>

      </div>

    </section>
  );
};

export default CorporatePackages;