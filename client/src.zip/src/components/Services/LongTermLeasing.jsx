import {
  FaCarSide,
  FaCalendarAlt,
  FaShieldAlt,
  FaTools,
  FaCheckCircle,
  FaArrowRight,
} from "../Icons/FaFallback";


const leasingPlans = [
  {
    id: 1,
    title: "6 Month Lease",
    image:
      "https://images.unsplash.com/photo-1553440569-bcc63803a83d?auto=format&fit=crop&w=1200&q=80",

    price: "₹24,999",
    duration: "/Month",

    vehicle: "Sedan / Hatchback",
    maintenance: "Free Maintenance",
    insurance: "Comprehensive Insurance",

    features: [
      "No Down Payment",
      "Routine Service Included",
      "Roadside Assistance",
      "Easy Upgrade Option",
    ],
  },

  {
    id: 2,
    title: "12 Month Lease",
    image:
      "https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80",

    price: "₹19,999",
    duration: "/Month",

    vehicle: "SUV / Premium Sedan",
    maintenance: "Free Maintenance",
    insurance: "Full Insurance Included",

    features: [
      "Unlimited Support",
      "Replacement Vehicle",
      "Flexible Contract",
      "Scheduled Maintenance",
    ],
  },

  {
    id: 3,
    title: "24 Month Lease",
    image:
      "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=1200&q=80",

    price: "₹16,999",
    duration: "/Month",

    vehicle: "Luxury Fleet",
    maintenance: "Premium Maintenance",
    insurance: "Premium Coverage",

    features: [
      "Lowest Monthly Cost",
      "Priority Customer Support",
      "Free Vehicle Replacement",
      "Dedicated Relationship Manager",
    ],
  },
];

const LongTermLeasing = () => {
  return (
    <section className="leasing-section">

      <div className="leasing-container">

        <div className="leasing-header">

          <span className="section-tag">
            Long Term Leasing
          </span>

          <h2>
            Flexible Vehicle Leasing Solutions
          </h2>

          <p>
            Lease a vehicle for months instead of
            purchasing one. Enjoy fixed monthly
            payments, maintenance coverage, insurance,
            and hassle-free ownership.
          </p>

        </div>

        <div className="leasing-grid">

          {leasingPlans.map((plan) => (

            <div
              className="leasing-card"
              key={plan.id}
            >

              <div className="leasing-image">

                <img
                  src={plan.image}
                  alt={plan.title}
                />

                <span className="lease-badge">
                  {plan.vehicle}
                </span>

              </div>

              <div className="leasing-content">

                <h3>{plan.title}</h3>

                <div className="leasing-price">

                  <h2>{plan.price}</h2>

                  <span>{plan.duration}</span>

                </div>

                <div className="leasing-info">

                  <div>

                    <FaCarSide />

                    <span>{plan.vehicle}</span>

                  </div>

                  <div>

                    <FaTools />

                    <span>{plan.maintenance}</span>

                  </div>

                  <div>

                    <FaShieldAlt />

                    <span>{plan.insurance}</span>

                  </div>

                  <div>

                    <FaCalendarAlt />

                    <span>{plan.title}</span>

                  </div>

                </div>

                <div className="leasing-features">

                  {plan.features.map(
                    (feature, index) => (

                      <div
                        className="feature"
                        key={index}
                      >

                        <FaCheckCircle />

                        <span>{feature}</span>

                      </div>

                    )
                  )}

                </div>
                                <div className="leasing-actions">

                  <button className="lease-btn">
                    Lease Now
                    <FaArrowRight />
                  </button>

                  <button className="details-btn">
                    View Details
                  </button>

                </div>

              </div>

            </div>

          ))}

        </div>

        {/* =====================================
            WHY CHOOSE LONG TERM LEASING
        ===================================== */}

        <div className="leasing-benefits">

          <div className="benefit-card">

            <FaCarSide />

            <h4>Latest Vehicle Fleet</h4>

            <p>
              Drive the latest models without worrying
              about depreciation, resale value, or
              ownership responsibilities.
            </p>

          </div>

          <div className="benefit-card">

            <FaTools />

            <h4>Maintenance Included</h4>

            <p>
              Routine servicing, repairs, and scheduled
              maintenance are included throughout your
              lease period at no extra cost.
            </p>

          </div>

          <div className="benefit-card">

            <FaShieldAlt />

            <h4>Insurance Coverage</h4>

            <p>
              Every lease includes comprehensive
              insurance coverage and 24/7 roadside
              assistance for complete peace of mind.
            </p>

          </div>

        </div>

      </div>

    </section>
  );
};

export default LongTermLeasing;