import {
  FaTools,
  FaBatteryHalf,
  FaGasPump,
  FaTruck,
  FaPhoneAlt,
  FaCheckCircle,
  FaArrowRight,
} from "../Icons/FaFallback";


const assistanceServices = [
  {
    id: 1,
    title: "Flat Tyre Assistance",
    image:
      "https://images.unsplash.com/photo-1489824904134-891ab64532f1?auto=format&fit=crop&w=1200&q=80",

    response: "Arrival in 30-45 Minutes",
    availability: "24/7 Service",
    charge: "Starting from ₹499",

    features: [
      "Tyre Replacement",
      "Emergency Repair",
      "Professional Technician",
      "Available Everywhere",
    ],
  },

  {
    id: 2,
    title: "Battery Jump Start",
    image:
      "https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80",

    response: "Arrival in 25 Minutes",
    availability: "24/7 Service",
    charge: "Starting from ₹399",

    features: [
      "Battery Jump Start",
      "Battery Check",
      "Quick Service",
      "Certified Technician",
    ],
  },

  {
    id: 3,
    title: "Emergency Fuel Delivery",
    image:
      "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=1200&q=80",

    response: "Arrival in 35 Minutes",
    availability: "24/7 Service",
    charge: "Starting from ₹599",

    features: [
      "Fuel Delivery",
      "Diesel & Petrol",
      "Quick Dispatch",
      "Safe Handling",
    ],
  },

  {
    id: 4,
    title: "Vehicle Towing",
    image:
      "https://images.unsplash.com/photo-1502877338535-766e1452684a?auto=format&fit=crop&w=1200&q=80",

    response: "Arrival in 45 Minutes",
    availability: "Available 24/7",
    charge: "Starting from ₹999",

    features: [
      "Safe Towing",
      "Long Distance",
      "GPS Tracking",
      "Experienced Operators",
    ],
  },
];

const RoadsideAssistance = () => {
  return (
    <section className="roadside-section">

      <div className="roadside-container">

        <div className="roadside-header">

          <span className="section-tag">
            24/7 Roadside Assistance
          </span>

          <h2>
            Emergency Help Whenever You Need It
          </h2>

          <p>
            Our trained roadside assistance team is
            available 24 hours a day to help with flat
            tyres, battery issues, emergency fuel
            delivery, towing services, and more.
          </p>

        </div>

        <div className="roadside-grid">

          {assistanceServices.map((service) => (

            <div
              className="roadside-card"
              key={service.id}
            >

              <div className="roadside-image">

                <img
                  src={service.image}
                  alt={service.title}
                />

                <span className="service-badge">
                  {service.availability}
                </span>

              </div>

              <div className="roadside-content">

                <h3>{service.title}</h3>

                <div className="roadside-price">

                  <h2>{service.charge}</h2>

                </div>

                <div className="roadside-info">

                  <div>

                    <FaTools />

                    <span>{service.response}</span>

                  </div>

                  <div>

                    <FaPhoneAlt />

                    <span>{service.availability}</span>

                  </div>

                  <div>

                    <FaTruck />

                    <span>Professional Assistance</span>

                  </div>

                </div>

                <div className="roadside-features">

                  {service.features.map(
                    (feature, index) => (

                      <div
                        className="feature"
                        key={index}
                      >

                        <FaCheckCircle />

                        <span>{feature}</span>

                      </div>

                    )
                  )}

                </div>
                                <div className="roadside-actions">

                  <button className="call-btn">
                    Call Now
                    <FaArrowRight />
                  </button>

                  <button className="details-btn">
                    Learn More
                  </button>

                </div>

              </div>

            </div>

          ))}

        </div>

        {/* =====================================
            WHY CHOOSE OUR ROADSIDE ASSISTANCE
        ===================================== */}

        <div className="roadside-benefits">

          <div className="benefit-card">

            <FaTools />

            <h4>24/7 Emergency Support</h4>

            <p>
              Our roadside assistance team is available
              around the clock to help you anytime,
              anywhere, ensuring you're never stranded.
            </p>

          </div>

          <div className="benefit-card">

            <FaBatteryHalf />

            <h4>Fast Response Time</h4>

            <p>
              Our trained technicians are dispatched
              immediately, with an average arrival time
              of 30 to 45 minutes depending on location.
            </p>

          </div>

          <div className="benefit-card">

            <FaGasPump />

            <h4>Complete Roadside Solutions</h4>

            <p>
              From flat tyres and battery jump-starts
              to emergency fuel delivery and towing,
              we've got every roadside emergency covered.
            </p>

          </div>

        </div>

      </div>

    </section>
  );
};

export default RoadsideAssistance;