const BookingSteps = () => {
  const steps = [
    { title: "Choose Car", desc: "Pick the vehicle that matches your needs." },
    { title: "Select Dates", desc: "Set pickup and return times." },
    { title: "Confirm Booking", desc: "Review pricing and confirm." },
    { title: "Get Ready to Drive", desc: "We’ll help you with pickup details." },
  ];

  return (
    <section className="py-10 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-gray-900">How Booking Works</h2>
        <div className="mt-8 grid grid-cols-1 md:grid-cols-4 gap-4">
          {steps.map((s, idx) => (
            <div key={s.title} className="border rounded-xl p-5 shadow-sm bg-gray-50">
              <div className="text-sm font-semibold text-gray-600">Step {idx + 1}</div>
              <div className="mt-2 font-semibold text-gray-900">{s.title}</div>
              <div className="mt-2 text-sm text-gray-600">{s.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BookingSteps;

