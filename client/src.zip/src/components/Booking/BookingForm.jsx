import { useState } from "react";
import {
  FaUser,
  FaPhoneAlt,
  FaEnvelope,
  FaIdCard,
  FaCar,
  FaMapMarkerAlt,
  FaCalendarAlt,
  FaClock,
} from "../Icons/FaFallback";


const BookingForm = () => {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    age: "",
    licenseNumber: "",

    pickupLocation: "",
    dropLocation: "",

    pickupDate: "",
    pickupTime: "",

    returnDate: "",
    returnTime: "",

    emergencyName: "",
    emergencyPhone: "",

    specialRequest: "",

    agree: false,
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    setFormData({
      ...formData,
      [name]:
        type === "checkbox"
          ? checked
          : value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    console.log(formData);

    alert("Booking Details Saved Successfully!");
  };

  return (
    <section className="booking-form-section">
      <div className="booking-container">

        <div className="booking-title">
          <h2>Booking Information</h2>

          <p>
            Fill in your details to continue your
            vehicle reservation.
          </p>
        </div>

        <form
          className="booking-form"
          onSubmit={handleSubmit}
        >

          {/* ======================
             CUSTOMER INFORMATION
          ======================= */}

          <div className="form-card">

            <h3>Customer Information</h3>

            <div className="form-grid">

              <div className="input-group">
                <label>
                  <FaUser />
                  Full Name
                </label>

                <input
                  type="text"
                  name="fullName"
                  placeholder="Enter your name"
                  value={formData.fullName}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="input-group">
                <label>
                  <FaEnvelope />
                  Email Address
                </label>

                <input
                  type="email"
                  name="email"
                  placeholder="example@gmail.com"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="input-group">
                <label>
                  <FaPhoneAlt />
                  Mobile Number
                </label>

                <input
                  type="tel"
                  name="phone"
                  placeholder="+91 XXXXX XXXXX"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="input-group">
                <label>
                  <FaIdCard />
                  Age
                </label>

                <input
                  type="number"
                  name="age"
                  placeholder="Enter age"
                  value={formData.age}
                  onChange={handleChange}
                  required
                />
              </div>

            </div>

          </div>

          {/* ======================
              DRIVER INFORMATION
          ======================= */}

          <div className="form-card">

            <h3>Driver Information</h3>

            <div className="form-grid">

              <div className="input-group">
                <label>
                  <FaCar />
                  Driving License Number
                </label>

                <input
                  type="text"
                  name="licenseNumber"
                  placeholder="TN00XXXXXXXXXX"
                  value={formData.licenseNumber}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="input-group">
                <label>
                  <FaMapMarkerAlt />
                  Pickup Location
                </label>

                <input
                  type="text"
                  name="pickupLocation"
                  placeholder="Enter pickup location"
                  value={formData.pickupLocation}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="input-group">
                <label>
                  <FaMapMarkerAlt />
                  Drop Location
                </label>

                <input
                  type="text"
                  name="dropLocation"
                  placeholder="Enter drop location"
                  value={formData.dropLocation}
                  onChange={handleChange}
                  required
                />
              </div>

            </div>

          </div>
                    {/* ======================
              RENTAL SCHEDULE
          ======================= */}

          <div className="form-card">

            <h3>Rental Schedule</h3>

            <div className="form-grid">

              <div className="input-group">
                <label>
                  <FaCalendarAlt />
                  Pickup Date
                </label>

                <input
                  type="date"
                  name="pickupDate"
                  value={formData.pickupDate}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="input-group">
                <label>
                  <FaClock />
                  Pickup Time
                </label>

                <input
                  type="time"
                  name="pickupTime"
                  value={formData.pickupTime}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="input-group">
                <label>
                  <FaCalendarAlt />
                  Return Date
                </label>

                <input
                  type="date"
                  name="returnDate"
                  value={formData.returnDate}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="input-group">
                <label>
                  <FaClock />
                  Return Time
                </label>

                <input
                  type="time"
                  name="returnTime"
                  value={formData.returnTime}
                  onChange={handleChange}
                  required
                />
              </div>

            </div>

          </div>

          {/* ======================
              EMERGENCY CONTACT
          ======================= */}

          <div className="form-card">

            <h3>Emergency Contact</h3>

            <div className="form-grid">

              <div className="input-group">
                <label>
                  <FaUser />
                  Contact Person
                </label>

                <input
                  type="text"
                  name="emergencyName"
                  placeholder="Emergency contact name"
                  value={formData.emergencyName}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="input-group">
                <label>
                  <FaPhoneAlt />
                  Contact Number
                </label>

                <input
                  type="tel"
                  name="emergencyPhone"
                  placeholder="+91 XXXXX XXXXX"
                  value={formData.emergencyPhone}
                  onChange={handleChange}
                  required
                />
              </div>

            </div>

          </div>

          {/* ======================
              SPECIAL REQUEST
          ======================= */}

          <div className="form-card">

            <h3>Special Requests</h3>

            <div className="input-group">

              <textarea
                name="specialRequest"
                rows="6"
                placeholder="Mention child seat, additional driver, airport pickup or any other requests..."
                value={formData.specialRequest}
                onChange={handleChange}
              ></textarea>

            </div>

          </div>

          {/* ======================
              TERMS
          ======================= */}

          <div className="terms-box">

            <label className="checkbox">

              <input
                type="checkbox"
                name="agree"
                checked={formData.agree}
                onChange={handleChange}
                required
              />

              <span>
                I agree to the Terms & Conditions,
                Privacy Policy, Fuel Policy and Rental
                Agreement.
              </span>

            </label>

          </div>

          {/* ======================
              SUBMIT BUTTON
          ======================= */}

          <div className="submit-area">

            <button
              type="submit"
              className="booking-submit-btn"
            >
              Continue to Add-ons
            </button>

          </div>

        </form>

      </div>
    </section>
  );
};

export default BookingForm;