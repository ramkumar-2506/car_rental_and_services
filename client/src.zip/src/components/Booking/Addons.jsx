import { useState } from "react";
import {
  FaUserTie,
  FaMapMarkedAlt,
  FaBaby,
  FaWifi,
  FaShieldAlt,
  FaSuitcase,
  FaCheckCircle,
} from "react-icons/fa";
import "./Addons.css";

const addonList = [
  {
    id: 1,
    icon: <FaUserTie />,
    title: "Professional Driver",
    description:
      "Hire an experienced driver for a safe and comfortable journey.",
    price: 1200,
  },
  {
    id: 2,
    icon: <FaMapMarkedAlt />,
    title: "GPS Navigation",
    description:
      "Get built-in GPS navigation with real-time route assistance.",
    price: 300,
  },
  {
    id: 3,
    icon: <FaBaby />,
    title: "Child Safety Seat",
    description:
      "Comfortable and certified child safety seat for your little one.",
    price: 500,
  },
  {
    id: 4,
    icon: <FaWifi />,
    title: "Portable Wi-Fi",
    description:
      "Unlimited high-speed internet during your rental period.",
    price: 450,
  },
  {
    id: 5,
    icon: <FaShieldAlt />,
    title: "Premium Insurance",
    description:
      "Additional insurance coverage with lower liability.",
    price: 900,
  },
  {
    id: 6,
    icon: <FaSuitcase />,
    title: "Roof Luggage Carrier",
    description:
      "Extra luggage space for long trips and family vacations.",
    price: 650,
  },
];

const Addons = () => {
  const [selectedAddons, setSelectedAddons] = useState([]);

  const toggleAddon = (addon) => {
    const exists = selectedAddons.find(
      (item) => item.id === addon.id
    );

    if (exists) {
      setSelectedAddons(
        selectedAddons.filter(
          (item) => item.id !== addon.id
        )
      );
    } else {
      setSelectedAddons([
        ...selectedAddons,
        addon,
      ]);
    }
  };

  const totalPrice = selectedAddons.reduce(
    (total, addon) => total + addon.price,
    0
  );

  return (
    <section className="addons-section">
      <div className="addons-container">

        <div className="addons-header">
          <h2>Choose Your Add-ons</h2>

          <p>
            Customize your rental experience by selecting
            additional services and accessories.
          </p>
        </div>

        <div className="addons-grid">

          {addonList.map((addon) => {

            const isSelected = selectedAddons.some(
              (item) => item.id === addon.id
            );

            return (

              <div
                key={addon.id}
                className={`addon-card ${
                  isSelected ? "selected" : ""
                }`}
              >

                <div className="addon-icon">
                  {addon.icon}
                </div>

                <h3>{addon.title}</h3>

                <p>{addon.description}</p>

                <div className="addon-price">
                  ₹{addon.price}
                </div>

                <button
                  onClick={() => toggleAddon(addon)}
                  className={
                    isSelected
                      ? "remove-btn"
                      : "add-btn"
                  }
                >
                  {isSelected ? (
                    <>
                      <FaCheckCircle />
                      Selected
                    </>
                  ) : (
                    "Add Service"
                  )}
                </button>

              </div>

            );

          })}

        </div>
                {/* ==========================
            SELECTED ADD-ONS SUMMARY
        ========================== */}

        <div className="addons-summary">

          <h3>Selected Add-ons</h3>

          {selectedAddons.length === 0 ? (

            <div className="empty-summary">
              <p>No add-on services selected.</p>
            </div>

          ) : (

            <>
              <div className="selected-list">

                {selectedAddons.map((addon) => (

                  <div
                    className="selected-item"
                    key={addon.id}
                  >
                    <span>{addon.title}</span>

                    <strong>
                      ₹{addon.price}
                    </strong>
                  </div>

                ))}

              </div>

              <div className="summary-total">

                <span>Total Add-on Cost</span>

                <h2>
                  ₹{totalPrice.toLocaleString()}
                </h2>

              </div>

            </>

          )}

        </div>

        {/* ==========================
            ACTION BUTTONS
        ========================== */}

        <div className="addons-actions">

          <button
            className="skip-btn"
            type="button"
          >
            Skip Add-ons
          </button>

          <button
            className="continue-btn"
            type="button"
          >
            Continue to Insurance
          </button>

        </div>

      </div>
    </section>
  );
};

export default Addons;