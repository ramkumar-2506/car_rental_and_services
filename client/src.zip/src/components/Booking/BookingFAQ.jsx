import faqs from "../../data/faqs";

const BookingFAQ = () => {
  const list = Array.isArray(faqs) ? faqs : [];
  const items = list.length ? list.slice(0, 6) : [];

  return (
    <section className="py-12 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-gray-900">Booking FAQs</h2>

        {items.length ? (
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-4">
            {items.map((f) => (
              <div key={f.question || f.title} className="border rounded-xl p-6 shadow-sm bg-gray-50">
                <div className="font-semibold text-gray-900">{f.question || f.title}</div>
                <div className="mt-2 text-gray-600">{f.answer || f.description}</div>
              </div>
            ))}
          </div>
        ) : (
          <p className="mt-6 text-gray-600">No FAQs available.</p>
        )}
      </div>
    </section>
  );
};

export default BookingFAQ;

