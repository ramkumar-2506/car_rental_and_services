const PaymentOptions = () => {
  return (
    <section className="py-10 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-gray-900">Payment Options</h2>
        <p className="mt-3 text-gray-600">
          Choose how you want to pay. Final payment method will be confirmed at checkout.
        </p>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { title: "UPI / Cards", desc: "Quick and secure digital payments." },
            { title: "Cash on Pickup", desc: "Pay when you receive your car." },
            { title: "Corporate Billing", desc: "For businesses and bulk bookings." },
          ].map((x) => (
            <div key={x.title} className="bg-white border rounded-xl p-6 shadow-sm">
              <div className="font-semibold text-gray-900">{x.title}</div>
              <div className="mt-2 text-gray-600">{x.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PaymentOptions;

