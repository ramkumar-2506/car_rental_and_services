import FleetCard from "./FleetCard";


const economyCars = [
  {
    id: 1,
    name: "Maruti Suzuki Swift",
    category: "Economy",
    image:
      "https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=900",
    price: 1499,
    description:
      "A fuel-efficient hatchback perfect for city commuting and weekend trips.",
    seats: 5,
    luggage: 2,
    fuel: "Petrol",
    transmission: "Manual",
  },

  {
    id: 2,
    name: "Hyundai Grand i10",
    category: "Economy",
    image:
      "https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=900",
    price: 1599,
    description:
      "Compact, comfortable, and ideal for daily travel with excellent mileage.",
    seats: 5,
    luggage: 2,
    fuel: "Petrol",
    transmission: "Automatic",
  },

  {
    id: 3,
    name: "Tata Tiago",
    category: "Economy",
    image:
      "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=900",
    price: 1699,
    description:
      "Affordable hatchback with modern safety features and comfortable interiors.",
    seats: 5,
    luggage: 2,
    fuel: "Petrol",
    transmission: "Manual",
  },

  {
    id: 4,
    name: "Renault Kwid",
    category: "Economy",
    image:
      "https://images.unsplash.com/photo-1553440569-bcc63803a83d?w=900",
    price: 1399,
    description:
      "A compact city car offering excellent fuel economy and easy parking.",
    seats: 5,
    luggage: 2,
    fuel: "Petrol",
    transmission: "Manual",
  },

  {
    id: 5,
    name: "Maruti WagonR",
    category: "Economy",
    image:
      "https://images.unsplash.com/photo-1502877338535-766e1452684a?w=900",
    price: 1549,
    description:
      "Spacious cabin, reliable performance, and ideal for family city rides.",
    seats: 5,
    luggage: 3,
    fuel: "CNG",
    transmission: "Manual",
  },

  {
    id: 6,
    name: "Hyundai Exter",
    category: "Economy SUV",
    image:
      "https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?w=900",
    price: 1899,
    description:
      "Entry-level SUV with modern technology and excellent driving comfort.",
    seats: 5,
    luggage: 3,
    fuel: "Petrol",
    transmission: "Automatic",
  },
];

const EconomyCars = () => {
  return (
    <section className="economy-section">

      <div className="economy-container">

        <div className="economy-header">

          <span className="section-tag">
            Economy Fleet
          </span>

          <h2>
            Affordable Cars For Every Journey
          </h2>

          <p>
            Explore our collection of fuel-efficient economy
            cars designed for daily commuting, business trips,
            family travel, and budget-friendly road adventures.
          </p>

        </div>

        <div className="fleet-grid">

          {economyCars.map((car) => (
            <FleetCard
              key={car.id}
              car={car}
            />
          ))}
                  </div>

        {/* ===========================
            FLEET STATISTICS
        =========================== */}

        <div className="economy-stats">

          <div className="stat-box">

            <h3>50+</h3>

            <span>Economy Cars</span>

          </div>

          <div className="stat-box">

            <h3>₹1,399</h3>

            <span>Starting Price / Day</span>

          </div>

          <div className="stat-box">

            <h3>24/7</h3>

            <span>Roadside Assistance</span>

          </div>

          <div className="stat-box">

            <h3>100%</h3>

            <span>Well Maintained Fleet</span>

          </div>

        </div>

        {/* ===========================
            CALL TO ACTION
        =========================== */}

        <div className="economy-cta">

          <h2>
            Find The Perfect Economy Car Today
          </h2>

          <p>
            Whether you're planning a weekend getaway,
            a business trip, or your daily commute,
            our economy fleet offers the perfect balance
            of affordability, comfort, and fuel efficiency.
          </p>

          <button className="economy-btn">
            Explore More Cars
          </button>

        </div>

      </div>

    </section>
  );
};

export default EconomyCars;