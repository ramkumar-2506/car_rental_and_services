import { FaUsers, FaTools as FaSuitcase, FaGasPump, FaCogs as FaCog, FaArrowRight } from "../Icons/FaFallback";


const FleetCard = ({ car }) => {
  return (
    <div className="fleet-card">

      {/* Car Image */}
      <div className="fleet-image">

        <img
          src={car.image}
          alt={car.name}
        />

        <span className="fleet-badge">
          {car.category}
        </span>

      </div>

      {/* Car Details */}
      <div className="fleet-content">

        <div className="fleet-top">

          <h3>{car.name}</h3>

          <div className="fleet-price">

            <span className="price">
              ₹{car.price}
            </span>

            <small>/ Day</small>

          </div>

        </div>

        <p className="fleet-description">
          {car.description}
        </p>

        {/* Features */}

        <div className="fleet-features">

          <div className="feature">

            <FaUsers />

            <span>{car.seats} Seats</span>

          </div>

          <div className="feature">

            <FaSuitcase />

            <span>{car.luggage} Bags</span>

          </div>

          <div className="feature">

            <FaGasPump />

            <span>{car.fuel}</span>

          </div>

          <div className="feature">

            <FaCog />

            <span>{car.transmission}</span>

          </div>

        </div>
                {/* ===========================
            ACTION BUTTONS
        =========================== */}

        <div className="fleet-actions">

          <button className="details-btn">

            View Details

          </button>

          <button className="book-btn">

            Book Now

            <FaArrowRight />

          </button>

        </div>

      </div>

    </div>
  );
};

export default FleetCard;