import FleetCard from "./FleetCard";


const luxuryCars = [
  {
    id: 1,
    name: "BMW 5 Series",
    category: "Luxury Sedan",
    image:
      "https://images.unsplash.com/photo-1555215695-3004980ad54e?w=900",
    price: 7499,
    description:
      "Premium executive sedan offering exceptional comfort, advanced technology, and outstanding performance.",
    seats: 5,
    luggage: 4,
    fuel: "Petrol",
    transmission: "Automatic",
  },

  {
    id: 2,
    name: "Mercedes-Benz C-Class",
    category: "Luxury Sedan",
    image:
      "https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=900",
    price: 7999,
    description:
      "Elegant luxury sedan with refined interiors, cutting-edge safety features, and a smooth driving experience.",
    seats: 5,
    luggage: 4,
    fuel: "Petrol",
    transmission: "Automatic",
  },

  {
    id: 3,
    name: "Audi A6",
    category: "Luxury Sedan",
    image:
      "https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=900",
    price: 8299,
    description:
      "Modern luxury sedan featuring premium craftsmanship, powerful performance, and advanced infotainment.",
    seats: 5,
    luggage: 4,
    fuel: "Petrol",
    transmission: "Automatic",
  },

  {
    id: 4,
    name: "Volvo XC60",
    category: "Luxury SUV",
    image:
      "https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?w=900",
    price: 8999,
    description:
      "Sophisticated SUV delivering world-class safety, luxurious interiors, and superior driving comfort.",
    seats: 5,
    luggage: 5,
    fuel: "Hybrid",
    transmission: "Automatic",
  },

  {
    id: 5,
    name: "Toyota Fortuner Legender",
    category: "Premium SUV",
    image:
      "https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=900",
    price: 6999,
    description:
      "Premium SUV built for luxury, adventure, and long-distance travel with exceptional reliability.",
    seats: 7,
    luggage: 5,
    fuel: "Diesel",
    transmission: "Automatic",
  },

  {
    id: 6,
    name: "Range Rover Velar",
    category: "Luxury SUV",
    image:
      "https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=900",
    price: 11999,
    description:
      "Experience unmatched luxury, powerful performance, and iconic design in every journey.",
    seats: 5,
    luggage: 5,
    fuel: "Petrol",
    transmission: "Automatic",
  },
];

const LuxuryCars = () => {
  return (
    <section className="luxury-section">

      <div className="luxury-container">

        <div className="luxury-header">

          <span className="section-tag">
            Luxury Fleet
          </span>

          <h2>
            Drive Premium Luxury Vehicles
          </h2>

          <p>
            Choose from our exclusive collection of luxury
            sedans and premium SUVs designed to provide
            elegance, comfort, performance, and an
            unforgettable driving experience.
          </p>

        </div>

        <div className="fleet-grid">

          {luxuryCars.map((car) => (
            <FleetCard
              key={car.id}
              car={car}
            />
          ))}
                  </div>

        {/* ===========================
            LUXURY FLEET STATISTICS
        =========================== */}

        <div className="luxury-stats">

          <div className="stat-box">

            <h3>30+</h3>

            <span>Luxury Vehicles</span>

          </div>

          <div className="stat-box">

            <h3>₹6,999</h3>

            <span>Starting Price / Day</span>

          </div>

          <div className="stat-box">

            <h3>24/7</h3>

            <span>VIP Customer Support</span>

          </div>

          <div className="stat-box">

            <h3>100%</h3>

            <span>Premium Maintained Fleet</span>

          </div>

        </div>

        {/* ===========================
            LUXURY CTA
        =========================== */}

        <div className="luxury-cta">

          <h2>
            Experience Luxury Like Never Before
          </h2>

          <p>
            Whether it's a corporate event, wedding,
            airport transfer, or a special occasion,
            our premium fleet delivers unmatched comfort,
            elegance, and performance for every journey.
          </p>

          <button className="luxury-btn">
            Reserve Your Luxury Car
          </button>

        </div>

      </div>

    </section>
  );
};

export default LuxuryCars;