import FleetCard from "./FleetCard";


const suvCars = [
  {
    id: 1,
    name: "Mahindra XUV700",
    category: "SUV",
    image:
      "https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=900",
    price: 3499,
    description:
      "Premium SUV with advanced safety features, spacious interiors, and powerful performance for every journey.",
    seats: 7,
    luggage: 5,
    fuel: "Diesel",
    transmission: "Automatic",
  },

  {
    id: 2,
    name: "Tata Safari",
    category: "SUV",
    image:
      "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=900",
    price: 3299,
    description:
      "Bold and spacious SUV designed for family trips with outstanding comfort and road presence.",
    seats: 7,
    luggage: 5,
    fuel: "Diesel",
    transmission: "Manual",
  },

  {
    id: 3,
    name: "Hyundai Creta",
    category: "SUV",
    image:
      "https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=900",
    price: 2899,
    description:
      "Stylish SUV featuring premium interiors, smart technology, and excellent fuel efficiency.",
    seats: 5,
    luggage: 4,
    fuel: "Petrol",
    transmission: "Automatic",
  },

  {
    id: 4,
    name: "Kia Seltos",
    category: "SUV",
    image:
      "https://images.unsplash.com/photo-1553440569-bcc63803a83d?w=900",
    price: 2999,
    description:
      "Modern SUV offering superior comfort, advanced infotainment, and dynamic driving performance.",
    seats: 5,
    luggage: 4,
    fuel: "Petrol",
    transmission: "Automatic",
  },

  {
    id: 5,
    name: "Toyota Fortuner",
    category: "Premium SUV",
    image:
      "https://images.unsplash.com/photo-1502877338535-766e1452684a?w=900",
    price: 4999,
    description:
      "Legendary SUV built for luxury, durability, and long-distance travel with exceptional reliability.",
    seats: 7,
    luggage: 5,
    fuel: "Diesel",
    transmission: "Automatic",
  },

  {
    id: 6,
    name: "MG Hector",
    category: "SUV",
    image:
      "https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?w=900",
    price: 3199,
    description:
      "Feature-rich SUV equipped with connected technology, panoramic sunroof, and premium interiors.",
    seats: 5,
    luggage: 4,
    fuel: "Petrol",
    transmission: "Automatic",
  },
];

const SUVs = () => {
  return (
    <section className="suv-section">

      <div className="suv-container">

        <div className="suv-header">

          <span className="section-tag">
            SUV Fleet
          </span>

          <h2>
            Powerful SUVs For Every Adventure
          </h2>

          <p>
            Discover our premium collection of SUVs designed
            for family vacations, business travel, off-road
            adventures, and comfortable long-distance journeys
            with unmatched performance and safety.
          </p>

        </div>

        <div className="fleet-grid">

          {suvCars.map((car) => (
            <FleetCard
              key={car.id}
              car={car}
            />
          ))}
                  </div>

        {/* ===========================
            SUV FLEET STATISTICS
        =========================== */}

        <div className="suv-stats">

          <div className="stat-box">

            <h3>40+</h3>

            <span>Premium SUVs</span>

          </div>

          <div className="stat-box">

            <h3>₹2,899</h3>

            <span>Starting Price / Day</span>

          </div>

          <div className="stat-box">

            <h3>24/7</h3>

            <span>Roadside Assistance</span>

          </div>

          <div className="stat-box">

            <h3>100%</h3>

            <span>Sanitized & Maintained</span>

          </div>

        </div>

        {/* ===========================
            CTA SECTION
        =========================== */}

        <div className="suv-cta">

          <h2>
            Choose Your Perfect SUV Today
          </h2>

          <p>
            From weekend getaways to family vacations and
            business travel, our SUV fleet delivers the
            perfect combination of space, safety, comfort,
            and performance for every road ahead.
          </p>

          <button className="suv-btn">
            Explore More SUVs
          </button>

        </div>

      </div>

    </section>
  );
};

export default SUVs;