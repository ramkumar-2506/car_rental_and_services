import FleetCard from "./FleetCard";


const electricCars = [
  {
    id: 1,
    name: "Tata Nexon EV",
    category: "Electric SUV",
    image:
      "https://images.unsplash.com/photo-1553440569-bcc63803a83d?w=900",
    price: 3499,
    description:
      "India's popular electric SUV offering excellent range, modern technology, and zero-emission driving.",
    seats: 5,
    luggage: 4,
    fuel: "Electric",
    transmission: "Automatic",
  },

  {
    id: 2,
    name: "MG ZS EV",
    category: "Electric SUV",
    image:
      "https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?w=900",
    price: 3999,
    description:
      "Premium electric SUV featuring advanced safety systems, connected technology, and a spacious cabin.",
    seats: 5,
    luggage: 5,
    fuel: "Electric",
    transmission: "Automatic",
  },

  {
    id: 3,
    name: "Mahindra XUV400 EV",
    category: "Electric SUV",
    image:
      "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=900",
    price: 3799,
    description:
      "Performance-oriented electric SUV delivering fast acceleration, long driving range, and premium comfort.",
    seats: 5,
    luggage: 4,
    fuel: "Electric",
    transmission: "Automatic",
  },

  {
    id: 4,
    name: "Hyundai Kona Electric",
    category: "Electric Crossover",
    image:
      "https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=900",
    price: 4299,
    description:
      "Compact electric crossover with impressive range, smart features, and exceptional ride quality.",
    seats: 5,
    luggage: 4,
    fuel: "Electric",
    transmission: "Automatic",
  },

  {
    id: 5,
    name: "BYD Atto 3",
    category: "Premium Electric SUV",
    image:
      "https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=900",
    price: 4699,
    description:
      "Modern premium electric SUV equipped with innovative technology, luxury interiors, and long-range capability.",
    seats: 5,
    luggage: 5,
    fuel: "Electric",
    transmission: "Automatic",
  },

  {
    id: 6,
    name: "Tata Punch EV",
    category: "Electric Compact SUV",
    image:
      "https://images.unsplash.com/photo-1502877338535-766e1452684a?w=900",
    price: 2999,
    description:
      "Compact electric SUV ideal for city driving with efficient battery performance and advanced safety features.",
    seats: 5,
    luggage: 3,
    fuel: "Electric",
    transmission: "Automatic",
  },
];

const ElectricCars = () => {
  return (
    <section className="electric-section">

      <div className="electric-container">

        <div className="electric-header">

          <span className="section-tag">
            Electric Fleet
          </span>

          <h2>
            Drive The Future With Electric Cars
          </h2>

          <p>
            Experience eco-friendly mobility with our premium
            fleet of electric vehicles, offering silent
            performance, zero emissions, cutting-edge
            technology, and exceptional driving comfort.
          </p>

        </div>

        <div className="fleet-grid">

          {electricCars.map((car) => (
            <FleetCard
              key={car.id}
              car={car}
            />
          ))}
                  </div>

        {/* ===========================
            ELECTRIC FLEET STATISTICS
        =========================== */}

        <div className="electric-stats">

          <div className="stat-box">

            <h3>35+</h3>

            <span>Electric Vehicles</span>

          </div>

          <div className="stat-box">

            <h3>₹2,999</h3>

            <span>Starting Price / Day</span>

          </div>

          <div className="stat-box">

            <h3>450 KM</h3>

            <span>Maximum Driving Range</span>

          </div>

          <div className="stat-box">

            <h3>100%</h3>

            <span>Eco-Friendly Fleet</span>

          </div>

        </div>

        {/* ===========================
            CALL TO ACTION
        =========================== */}

        <div className="electric-cta">

          <h2>
            Switch To Sustainable Driving
          </h2>

          <p>
            Experience the future of mobility with our
            premium electric fleet. Enjoy smooth,
            silent, and environmentally friendly journeys
            while benefiting from advanced technology,
            exceptional comfort, and zero tailpipe emissions.
          </p>

          <button className="electric-btn">
            Book An Electric Car
          </button>

        </div>

      </div>

    </section>
  );
};

export default ElectricCars;