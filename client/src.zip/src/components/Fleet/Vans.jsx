import FleetCard from "./FleetCard";


const vans = [
  {
    id: 1,
    name: "Toyota Innova Crysta",
    category: "Premium MPV",
    image:
      "https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=900",
    price: 4499,
    description:
      "Spacious premium MPV offering exceptional comfort, reliability, and smooth performance for family and business travel.",
    seats: 7,
    luggage: 5,
    fuel: "Diesel",
    transmission: "Automatic",
  },

  {
    id: 2,
    name: "Kia Carnival",
    category: "Luxury MPV",
    image:
      "https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?w=900",
    price: 6999,
    description:
      "Luxury MPV featuring premium interiors, captain seats, advanced technology, and unmatched passenger comfort.",
    seats: 7,
    luggage: 6,
    fuel: "Diesel",
    transmission: "Automatic",
  },

  {
    id: 3,
    name: "Maruti Suzuki Ertiga",
    category: "Family MPV",
    image:
      "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=900",
    price: 2799,
    description:
      "Comfortable family MPV with excellent fuel efficiency, spacious seating, and modern convenience features.",
    seats: 7,
    luggage: 4,
    fuel: "Petrol",
    transmission: "Manual",
  },

  {
    id: 4,
    name: "Toyota Rumion",
    category: "Family MPV",
    image:
      "https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=900",
    price: 2999,
    description:
      "Reliable multi-purpose vehicle designed for family trips with generous cabin space and comfortable seating.",
    seats: 7,
    luggage: 4,
    fuel: "Petrol",
    transmission: "Automatic",
  },

  {
    id: 5,
    name: "Force Urbania",
    category: "Luxury Van",
    image:
      "https://images.unsplash.com/photo-1553440569-bcc63803a83d?w=900",
    price: 8999,
    description:
      "Premium passenger van offering luxury seating, ample luggage space, and outstanding comfort for group travel.",
    seats: 12,
    luggage: 10,
    fuel: "Diesel",
    transmission: "Manual",
  },

  {
    id: 6,
    name: "Tempo Traveller",
    category: "Traveller Van",
    image:
      "https://images.unsplash.com/photo-1502877338535-766e1452684a?w=900",
    price: 9999,
    description:
      "Ideal choice for tours, corporate trips, pilgrimages, and large family vacations with spacious seating.",
    seats: 17,
    luggage: 14,
    fuel: "Diesel",
    transmission: "Manual",
  },
];

const Vans = () => {
  return (
    <section className="vans-section">

      <div className="vans-container">

        <div className="vans-header">

          <span className="section-tag">
            Vans & MPVs
          </span>

          <h2>
            Spacious Vans For Group & Family Travel
          </h2>

          <p>
            Explore our premium collection of vans and MPVs
            designed for family vacations, corporate travel,
            airport transfers, weddings, and group tours with
            maximum comfort and generous luggage capacity.
          </p>

        </div>

        <div className="fleet-grid">

          {vans.map((car) => (
            <FleetCard
              key={car.id}
              car={car}
            />
          ))}
                  </div>

        {/* ===========================
            VANS FLEET STATISTICS
        =========================== */}

        <div className="vans-stats">

          <div className="stat-box">

            <h3>25+</h3>

            <span>Premium Vans & MPVs</span>

          </div>

          <div className="stat-box">

            <h3>₹2,799</h3>

            <span>Starting Price / Day</span>

          </div>

          <div className="stat-box">

            <h3>17</h3>

            <span>Maximum Seating Capacity</span>

          </div>

          <div className="stat-box">

            <h3>24/7</h3>

            <span>Travel Assistance</span>

          </div>

        </div>

        {/* ===========================
            CALL TO ACTION
        =========================== */}

        <div className="vans-cta">

          <h2>
            Book The Perfect Van For Your Group
          </h2>

          <p>
            Whether you're planning a family vacation,
            corporate outing, wedding, pilgrimage, airport
            transfer, or a group tour, our spacious vans and
            MPVs ensure every passenger travels in comfort
            and style.
          </p>

          <button className="vans-btn">
            Book Your Van Today
          </button>

        </div>

      </div>

    </section>
  );
};

export default Vans;