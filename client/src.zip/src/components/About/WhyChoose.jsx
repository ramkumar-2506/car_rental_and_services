import {
  FaCarSide,
  FaUserTie,
  FaHeadset,
  FaShieldAlt,
  FaMoneyBillWave,
  FaClock,
  FaArrowRight,
} from "../Icons/FaFallback";

const features = [
  {
    id: 1,
    icon: <FaCarSide />,
    title: "Premium Fleet",
    description:
      "Choose from luxury sedans, SUVs, hatchbacks, and premium vehicles that are regularly serviced and maintained.",
  },

  {
    id: 2,
    icon: <FaMoneyBillWave />,
    title: "Transparent Pricing",
    description:
      "No hidden charges. Enjoy competitive prices with complete transparency from booking to vehicle return.",
  },

  {
    id: 3,
    icon: <FaShieldAlt />,
    title: "Fully Insured Cars",
    description:
      "Every vehicle comes with comprehensive insurance coverage for a safe and worry-free journey.",
  },

  {
    id: 4,
    icon: <FaHeadset />,
    title: "24/7 Customer Support",
    description:
      "Our support team is always available to assist you before, during, and after your rental experience.",
  },

  {
    id: 5,
    icon: <FaClock />,
    title: "Instant Booking",
    description:
      "Book your preferred vehicle within minutes using our simple and secure online booking process.",
  },

  {
    id: 6,
    icon: <FaUserTie />,
    title: "Professional Chauffeurs",
    description:
      "Experienced and courteous drivers are available for business trips, airport transfers, and special occasions.",
  },
];

const WhyChoose = () => {
  return (
    <section className="whychoose-section">

      <div className="whychoose-container">

        <div className="whychoose-header">

          <span className="section-tag">
            Why Choose Us
          </span>

          <h2>
            Experience The Difference With Our
            Premium Car Rental Services
          </h2>

          <p>
            We combine a modern fleet, transparent
            pricing, experienced professionals, and
            exceptional customer support to deliver
            a seamless travel experience every time.
          </p>

        </div>

        <div className="whychoose-grid">

          {features.map((item) => (

            <div
              className="why-card"
              key={item.id}
            >

              <div className="why-icon">

                {item.icon}

              </div>

              <h3>{item.title}</h3>

              <p>{item.description}</p>

              <button className="learn-more">

                Learn More

                <FaArrowRight />

              </button>

            </div>

          ))}

        </div>
                {/* =====================================
            WHY CUSTOMERS PREFER US
        ===================================== */}

        <div className="why-extra">

          <div className="why-content">

            <span className="section-tag">
              Trusted By Thousands
            </span>

            <h2>
              Your Reliable Travel Partner For Every Journey
            </h2>

            <p>
              Whether you're planning a business trip,
              family vacation, airport transfer, or
              weekend getaway, we ensure every ride is
              comfortable, safe, and hassle-free with
              our premium rental services.
            </p>

            <ul>

              <li>
                <FaShieldAlt />
                <span>100% Well-Maintained & Sanitized Vehicles</span>
              </li>

              <li>
                <FaClock />
                <span>Quick Pickup & Easy Return Process</span>
              </li>

              <li>
                <FaMoneyBillWave />
                <span>Affordable Daily, Weekly & Monthly Rentals</span>
              </li>

              <li>
                <FaHeadset />
                <span>24/7 Customer Assistance & Roadside Support</span>
              </li>

            </ul>

          </div>

          <div className="why-image">

            <img
              src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80"
              alt="Car Rental Office"
            />

          </div>

        </div>

      </div>

    </section>
  );
};

export default WhyChoose;