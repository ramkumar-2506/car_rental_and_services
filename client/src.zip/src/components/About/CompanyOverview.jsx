import {
  FaBuilding,
  FaBullseye,
  FaEye,
  FaUsers,
  FaCarSide,
  FaAward,
  FaCheckCircle,
  FaArrowRight,
} from "../Icons/FaFallback";
const companyStats = [
  {
    id: 1,
    icon: <FaCarSide />,

    value: "500+",
    title: "Premium Vehicles",
  },
  {
    id: 2,
    icon: <FaUsers />,
    value: "15K+",
    title: "Happy Customers",
  },
  {
    id: 3,
    icon: <FaAward />,
    value: "10+",
    title: "Years Experience",
  },
  {
    id: 4,
    icon: <FaBuilding />,
    value: "25+",
    title: "Service Locations",
  },
];

const CompanyOverview = () => {
  return (
    <section className="company-overview">

      <div className="company-container">

        {/* =========================
             TOP SECTION
        ========================= */}

        <div className="company-top">

          <div className="company-image">

            <img
              src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80"
              alt="Company Office"
            />

          </div>

          <div className="company-content">

            <span className="section-tag">
              About Our Company
            </span>

            <h2>
              Driving Excellence With Trusted Car Rental
              Solutions
            </h2>

            <p>
              We are committed to providing safe,
              reliable, and affordable vehicle rental
              services for individuals, families, and
              businesses. Our mission is to make every
              journey comfortable through a modern fleet,
              transparent pricing, and exceptional
              customer support.
            </p>

            <div className="company-features">

              <div className="feature">

                <FaCheckCircle />

                <span>
                  Premium & Well Maintained Fleet
                </span>

              </div>

              <div className="feature">

                <FaCheckCircle />

                <span>
                  Transparent Pricing with No Hidden Fees
                </span>

              </div>

              <div className="feature">

                <FaCheckCircle />

                <span>
                  24/7 Customer & Roadside Assistance
                </span>

              </div>

              <div className="feature">

                <FaCheckCircle />

                <span>
                  Trusted by Thousands of Customers
                </span>

              </div>

            </div>

            <button className="company-btn">

              Explore Our Fleet

              <FaArrowRight />

            </button>

          </div>

        </div>

        {/* =========================
             MISSION & VISION
        ========================= */}

        <div className="mission-grid">

          <div className="mission-card">

            <FaBullseye />

            <h3>Our Mission</h3>

            <p>
              To deliver safe, affordable, and premium
              mobility solutions through quality
              vehicles, innovative technology, and
              outstanding customer service.
            </p>

          </div>

          <div className="mission-card">

            <FaEye />

            <h3>Our Vision</h3>

            <p>
              To become the most trusted car rental
              company by providing seamless travel
              experiences and continuously exceeding
              customer expectations.
            </p>

          </div>

        </div>

        {/* =========================
             COMPANY STATS
        ========================= */}

        <div className="stats-grid">

          {companyStats.map((stat) => (

            <div
              className="stat-card"
              key={stat.id}
            >

              <div className="stat-icon">

                {stat.icon}

              </div>

              <h3>{stat.value}</h3>

              <p>{stat.title}</p>

            </div>

          ))}
                  </div>

        {/* =========================
             CORE VALUES
        ========================= */}

        <div className="values-section">

          <h2>Our Core Values</h2>

          <p>
            Everything we do is guided by our commitment
            to quality, customer satisfaction, and
            continuous innovation.
          </p>

          <div className="values-grid">

            <div className="value-card">

              <FaCheckCircle />

              <h4>Customer First</h4>

              <p>
                Every decision we make is focused on
                delivering the best possible experience
                for our customers.
              </p>

            </div>

            <div className="value-card">

              <FaAward />

              <h4>Quality Service</h4>

              <p>
                We maintain our vehicles to the highest
                standards to ensure every journey is safe,
                comfortable, and reliable.
              </p>

            </div>

            <div className="value-card">

              <FaUsers />

              <h4>Integrity</h4>

              <p>
                Honest pricing, transparent policies,
                and ethical business practices are at
                the heart of everything we do.
              </p>

            </div>

            <div className="value-card">

              <FaBuilding />

              <h4>Innovation</h4>

              <p>
                We continuously improve our services
                using modern technology to make booking
                and travelling easier than ever.
              </p>

            </div>

          </div>

        </div>

        {/* =========================
             WHY CUSTOMERS TRUST US
        ========================= */}

        <div className="trust-section">

          <div className="trust-content">

            <h2>Why Thousands of Customers Trust Us</h2>

            <p>
              From short city rides to long-distance
              business trips, we provide dependable
              transportation backed by experienced
              professionals, transparent pricing,
              and 24/7 customer support.
            </p>

            <ul>

              <li>
                <FaCheckCircle />
                <span>No Hidden Charges</span>
              </li>

              <li>
                <FaCheckCircle />
                <span>Professional Customer Support</span>
              </li>

              <li>
                <FaCheckCircle />
                <span>Modern & Fully Insured Fleet</span>
              </li>

              <li>
                <FaCheckCircle />
                <span>Fast & Secure Online Booking</span>
              </li>

            </ul>

          </div>

          <div className="trust-image">

            <img
              src="https://images.unsplash.com/photo-1497366811353-6870744d04b2?auto=format&fit=crop&w=1200&q=80"
              alt="Customer Service"
            />

          </div>

        </div>

      </div>

    </section>
  );
};

export default CompanyOverview;