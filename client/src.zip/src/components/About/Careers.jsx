import {
  FaBriefcase,
  FaUsers,
  FaGraduationCap,
  FaLaptopCode,
  FaHeartbeat,
  FaMoneyCheckAlt,
  FaArrowRight,
} from "../Icons/FaFallback";




const careerBenefits = [
  {
    id: 1,
    icon: <FaBriefcase />,
    title: "Career Growth",
    description:
      "Grow your career with continuous learning, promotions, and leadership opportunities in a fast-growing company.",
  },

  {
    id: 2,
    icon: <FaUsers />,
    title: "Collaborative Culture",
    description:
      "Work with passionate professionals who value teamwork, innovation, and customer satisfaction.",
  },

  {
    id: 3,
    icon: <FaGraduationCap />,
    title: "Learning & Development",
    description:
      "Enhance your skills through workshops, certifications, technical training, and mentorship programs.",
  },

  {
    id: 4,
    icon: <FaLaptopCode />,
    title: "Modern Workplace",
    description:
      "Experience a technology-driven environment equipped with modern tools that encourage productivity and creativity.",
  },

  {
    id: 5,
    icon: <FaHeartbeat />,
    title: "Health & Wellness",
    description:
      "We care about employee well-being by promoting a healthy work-life balance and wellness initiatives.",
  },

  {
    id: 6,
    icon: <FaMoneyCheckAlt />,
    title: "Competitive Benefits",
    description:
      "Receive attractive salaries, performance incentives, paid leave, and employee recognition programs.",
  },
];

const Careers = () => {
  return (
    <section className="careers-section">

      <div className="careers-container">

        {/* ===========================
            HEADER
        =========================== */}

        <div className="careers-header">

          <span className="section-tag">
            Careers
          </span>

          <h2>
            Build Your Future With Our Team
          </h2>

          <p>
            We're always looking for passionate,
            talented, and motivated individuals who
            want to help shape the future of mobility.
            Join us and become part of a team that
            values innovation, collaboration, and
            customer excellence.
          </p>

        </div>

        {/* ===========================
            BENEFITS
        =========================== */}

        <div className="benefits-grid">

          {careerBenefits.map((benefit) => (

            <div
              className="benefit-card"
              key={benefit.id}
            >

              <div className="benefit-icon">

                {benefit.icon}

              </div>

              <h3>{benefit.title}</h3>

              <p>{benefit.description}</p>

              <button className="benefit-btn">

                Learn More

                <FaArrowRight />

              </button>

            </div>

          ))}

        </div>
                {/* ===========================
            JOIN OUR TEAM
        =========================== */}

        <div className="careers-cta">

          <div className="careers-content">

            <span className="section-tag">
              Join Our Journey
            </span>

            <h2>
              Ready To Build An Exciting Career?
            </h2>

            <p>
              Whether you're an experienced professional
              or just starting your career, we provide an
              environment where your ideas are valued,
              your skills are developed, and your work
              makes a real impact. Join us and help create
              exceptional travel experiences for thousands
              of customers every day.
            </p>

            <div className="career-highlights">

              <div className="highlight-item">
                ✓ Flexible Work Environment
              </div>

              <div className="highlight-item">
                ✓ Professional Training Programs
              </div>

              <div className="highlight-item">
                ✓ Performance-Based Rewards
              </div>

              <div className="highlight-item">
                ✓ Inclusive & Friendly Workplace
              </div>

            </div>

            <button className="apply-btn">

              Apply Now

              <FaArrowRight />

            </button>

          </div>

          <div className="careers-image">

            <img
              src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=80"
              alt="Join Our Team"
            />

          </div>

        </div>

      </div>

    </section>
  );
};

export default Careers;