import {
  FaLinkedinIn,
  FaTwitter,
  FaInstagram,
  FaEnvelope,
  FaAward,
  FaBriefcase,
  FaArrowRight,
} from "../Icons/FaFallback";



const TeamCard = ({ member }) => {
  return (
    <div className="team-card">

      {/* ==========================
          IMAGE
      ========================== */}

      <div className="team-image">

        <img
          src={member.image}
          alt={member.name}
        />

        <div className="team-social">

          <a href="#">
            <FaLinkedinIn />
          </a>

          <a href="#">
            <FaTwitter />
          </a>

          <a href="#">
            <FaInstagram />
          </a>

          <a href="#">
            <FaEnvelope />
          </a>

        </div>

      </div>

      {/* ==========================
          CONTENT
      ========================== */}

      <div className="team-content">

        <h3>{member.name}</h3>

        <span className="team-role">
          {member.role}
        </span>

        <p>
          {member.description}
        </p>

        <div className="team-info">

          <div className="info-item">

            <FaBriefcase />

            <span>{member.experience}</span>

          </div>

          <div className="info-item">

            <FaAward />

            <span>{member.specialization}</span>

          </div>

        </div>

        <button className="profile-btn">

          View Profile

          <FaArrowRight />

        </button>

      </div>
          </div>
  );
};

export default TeamCard;