import TeamCard from "./TeamCard";


const teamMembers = [
  {
    id: 1,
    name: "John Anderson",
    role: "Chief Executive Officer",
    image:
      "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=900&q=80",
    description:
      "John leads our company with over 15 years of experience in the automotive and mobility industry, driving innovation and customer satisfaction.",
    experience: "15+ Years",
    specialization: "Business Strategy",
  },

  {
    id: 2,
    name: "Sophia Williams",
    role: "Operations Manager",
    image:
      "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=900&q=80",
    description:
      "Sophia ensures our daily operations run smoothly while maintaining the highest standards of service quality across all locations.",
    experience: "10+ Years",
    specialization: "Operations",
  },

  {
    id: 3,
    name: "Michael Brown",
    role: "Fleet Manager",
    image:
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=900&q=80",
    description:
      "Michael oversees our premium fleet, ensuring every vehicle is maintained, inspected, and ready for a safe driving experience.",
    experience: "12+ Years",
    specialization: "Fleet Management",
  },

  {
    id: 4,
    name: "Emily Johnson",
    role: "Customer Relations Manager",
    image:
      "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=900&q=80",
    description:
      "Emily focuses on creating exceptional customer experiences by delivering personalized support and building long-term relationships.",
    experience: "8+ Years",
    specialization: "Customer Success",
  },

  {
    id: 5,
    name: "David Wilson",
    role: "Technical Manager",
    image:
      "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=900&q=80",
    description:
      "David manages our technical infrastructure, ensuring booking systems, fleet tracking, and digital services operate efficiently.",
    experience: "11+ Years",
    specialization: "Technology",
  },

  {
    id: 6,
    name: "Olivia Martinez",
    role: "Marketing Manager",
    image:
      "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=900&q=80",
    description:
      "Olivia develops marketing strategies that strengthen our brand presence and connect customers with our premium rental services.",
    experience: "9+ Years",
    specialization: "Digital Marketing",
  },
];

const Team = () => {
  return (
    <section className="team-section">

      <div className="team-container">

        <div className="team-header">

          <span className="section-tag">
            Meet Our Team
          </span>

          <h2>
            The Professionals Behind Our Success
          </h2>

          <p>
            Our experienced leadership team is committed
            to delivering exceptional customer service,
            maintaining a premium fleet, and providing
            reliable mobility solutions for every journey.
          </p>

        </div>

        <div className="team-grid">

          {teamMembers.map((member) => (

            <TeamCard
              key={member.id}
              member={member}
            />

          ))}
                  </div>

        {/* =====================================
            JOIN OUR TEAM
        ===================================== */}

        <div className="team-cta">

          <div className="team-cta-content">

            <h2>
              Passionate About Creating Great Travel Experiences?
            </h2>

            <p>
              We are always looking for talented professionals
              who are passionate about customer service,
              innovation, and delivering premium mobility
              solutions. Join our growing team and build
              your career with us.
            </p>

            <button className="join-btn">
              Join Our Team
            </button>

          </div>

          <div className="team-cta-image">

            <img
              src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1200&q=80"
              alt="Join Our Team"
            />

          </div>

        </div>

      </div>

    </section>
  );
};

export default Team;