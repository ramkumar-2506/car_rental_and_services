import { useState, useEffect } from "react";
import { Link, NavLink } from "react-router-dom";
import {
  FaBars,
  FaTimes,
  FaCarSide,
  FaPhoneAlt,
} from "../Icons/FaFallback";

// Tailwind migration: removed Navbar.css



const navLinks = [
  { name: "Home", path: "/" },

  { name: "About", path: "/about" },
  { name: "Services", path: "/services" },
  { name: "Fleet", path: "/fleet" },
  { name: "Booking", path: "/booking" },
  { name: "Contact", path: "/contact" },
];

const Navbar = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [sticky, setSticky] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setSticky(window.scrollY > 50);
    };

    window.addEventListener("scroll", handleScroll);

    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header className={`sticky top-0 z-50 ${sticky ? "bg-white shadow" : "bg-transparent"}`}>
    <div className="mx-auto max-w-6xl px-4">

        {/* Logo */}
        <Link to="/" className="flex items-center gap-3 py-4">
          <FaCarSide className="logo-icon" />
          <div>
            <h2 className="text-lg font-bold text-gray-900">DriveEase</h2>
            <span className="block text-xs text-gray-500">Car Rental & Services</span>
          </div>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-6">
          {navLinks.map((item) => (
            <NavLink
              key={item.name}
              to={item.path}
              onClick={() => setMenuOpen(false)}
              className={({ isActive }) =>
                isActive
                  ? "text-blue-600 font-semibold"
                  : "text-gray-700 hover:text-blue-600 transition"
              }
            >
              {item.name}
            </NavLink>
          ))}

          <a
            href="tel:+919876543210"
            className="inline-flex items-center gap-2 rounded-full bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700 transition"
          >
            <FaPhoneAlt />
            Call Now
          </a>
        </nav>

        {/* Book Now */}
        <Link
          to="/booking"
          className="hidden lg:inline-flex rounded-full bg-gray-900 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-800 transition"
        >
          Book Now
        </Link>

        {/* Mobile Menu */}
        <button
          className="lg:hidden inline-flex items-center justify-center rounded-md p-2"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? <FaTimes className="text-gray-700" /> : <FaBars className="text-gray-700" />}
        </button>

      </div>
    </header>
  );
};

export default Navbar;