import { FaArrowRight } from "react-icons/fa";
import { Link } from "react-router-dom";
import Button from "./Button";
import "./CTA.css";

const CTA = ({
  title = "Need a Rental Today?",
  subtitle = "Choose from our premium fleet and enjoy a safe, comfortable, and affordable journey. Book your ride in just a few clicks.",
  primaryText = "Book Now",
  primaryLink = "/booking",
  secondaryText = "Contact Us",
  secondaryLink = "/contact",
}) => {
  return (
    <section className="cta">
      <div className="cta-container">
        <div className="cta-content">
          <span className="cta-tag">Premium Car Rental</span>

          <h2>{title}</h2>

          <p>{subtitle}</p>

          <div className="cta-buttons">
            <Link to={primaryLink}>
              <Button
                text={primaryText}
                variant="primary"
                icon={<FaArrowRight />}
              />
            </Link>

            <Link to={secondaryLink}>
              <Button
                text={secondaryText}
                variant="outline"
              />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTA;