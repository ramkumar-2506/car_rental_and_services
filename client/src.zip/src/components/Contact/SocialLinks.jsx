import {
  FaFacebookF,
  FaInstagram,
  FaLinkedinIn,
  FaXTwitter,
  FaYoutube,
  FaArrowRight,
  FaWhatsapp,
} from "../Icons/FaFallback";



const socialPlatforms = [
  {
    id: 1,
    icon: <FaFacebookF />,
    name: "Facebook",
    username: "@CarRentalOfficial",
    description:
      "Stay updated with our latest offers, travel tips, customer stories, and exciting giveaways.",
    button: "Follow Us",
  },

  {
    id: 2,
    icon: <FaInstagram />,
    name: "Instagram",
    username: "@CarRentalOfficial",
    description:
      "Explore our premium fleet, travel destinations, behind-the-scenes moments, and customer experiences.",
    button: "Follow Us",
  },

  {
    id: 3,
    icon: <FaLinkedinIn />,
    name: "LinkedIn",
    username: "Car Rental Services",
    description:
      "Connect with us for corporate partnerships, company news, career opportunities, and business updates.",
    button: "Connect",
  },

  {
    id: 4,
    icon: <FaXTwitter />,
    name: "X (Twitter)",
    username: "@CarRental",
    description:
      "Receive instant announcements, customer support updates, and real-time travel information.",
    button: "Follow",
  },

  {
    id: 5,
    icon: <FaYoutube />,
    name: "YouTube",
    username: "Car Rental Official",
    description:
      "Watch vehicle walkthroughs, travel guides, customer testimonials, and service tutorials.",
    button: "Subscribe",
  },

  {
    id: 6,
    icon: <FaWhatsapp />,
    name: "WhatsApp",
    username: "+91 98765 43210",
    description:
      "Chat directly with our customer support team for bookings, inquiries, and instant assistance.",
    button: "Chat Now",
  },
];

const SocialLinks = () => {
  return (
    <section className="social-section">

      <div className="social-container">

        <div className="social-header">

          <span className="section-tag">
            Follow Us
          </span>

          <h2>
            Connect With Us On Social Media
          </h2>

          <p>
            Stay connected with us across all major social
            media platforms for travel inspiration, exclusive
            offers, customer support, and the latest updates
            from our car rental services.
          </p>

        </div>

        <div className="social-grid">

          {socialPlatforms.map((social) => (

            <div
              className="social-card"
              key={social.id}
            >

              <div className="social-icon">

                {social.icon}

              </div>

              <h3>{social.name}</h3>

              <h4>{social.username}</h4>

              <p>{social.description}</p>

              <button className="social-btn">

                {social.button}

                <FaArrowRight />

              </button>

            </div>

          ))}
                  </div>

        {/* ===========================
            COMMUNITY CTA
        =========================== */}

        <div className="community-section">

          <div className="community-content">

            <span className="section-tag">
              Join Our Community
            </span>

            <h2>
              Be Part Of Our Growing Travel Community
            </h2>

            <p>
              Follow us for exclusive discounts, travel
              inspiration, exciting giveaways, customer
              stories, new vehicle launches, and the latest
              updates from our car rental services. Join
              thousands of happy travelers who stay connected
              with us every day.
            </p>

            <button className="join-btn">

              Follow All Channels

              <FaArrowRight />

            </button>

          </div>

          <div className="community-stats">

            <div className="community-stat">

              <h3>50K+</h3>

              <span>Followers</span>

            </div>

            <div className="community-stat">

              <h3>15K+</h3>

              <span>Happy Customers</span>

            </div>

            <div className="community-stat">

              <h3>10+</h3>

              <span>Social Platforms</span>

            </div>

            <div className="community-stat">

              <h3>24/7</h3>

              <span>Online Support</span>

            </div>

          </div>

        </div>

      </div>

    </section>
  );
};

export default SocialLinks;