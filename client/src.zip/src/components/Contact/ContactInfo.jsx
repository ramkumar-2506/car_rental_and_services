import {
  FaMapMarkerAlt,
  FaPhoneAlt,
  FaEnvelope,
  FaClock,
  FaWhatsapp,
  FaHeadset,
  FaArrowRight,
} from "../Icons/FaFallback";



const contactDetails = [
  {
    id: 1,
    icon: <FaMapMarkerAlt />,
    title: "Our Office",
    value: "123 Anna Salai, Chennai, Tamil Nadu 600002",
    description:
      "Visit our headquarters for bookings, customer support, and business inquiries.",
  },

  {
    id: 2,
    icon: <FaPhoneAlt />,
    title: "Call Us",
    value: "+91 98765 43210",
    description:
      "Speak directly with our support team for reservations and assistance.",
  },

  {
    id: 3,
    icon: <FaEnvelope />,
    title: "Email Us",
    value: "support@carrental.com",
    description:
      "Send us your questions anytime and we'll respond as quickly as possible.",
  },

  {
    id: 4,
    icon: <FaClock />,
    title: "Working Hours",
    value: "Mon - Sun : 24 Hours",
    description:
      "Our booking and customer support team is available every day.",
  },

  {
    id: 5,
    icon: <FaWhatsapp />,
    title: "WhatsApp",
    value: "+91 98765 43210",
    description:
      "Quick booking assistance and live updates through WhatsApp.",
  },

  {
    id: 6,
    icon: <FaHeadset />,
    title: "24/7 Support",
    value: "Always Available",
    description:
      "Emergency roadside assistance and customer care whenever you need us.",
  },
];

const ContactInfo = () => {
  return (
    <section className="contact-info-section">

      <div className="contact-info-container">

        <div className="contact-header">

          <span className="section-tag">
            Contact Information
          </span>

          <h2>
            We're Here To Help You Anytime
          </h2>

          <p>
            Have questions about our services, bookings,
            pricing, or vehicle availability? Reach out to
            our friendly support team through any of the
            contact methods below.
          </p>

        </div>

        <div className="contact-grid">

          {contactDetails.map((item) => (

            <div
              className="contact-card"
              key={item.id}
            >

              <div className="contact-icon">

                {item.icon}

              </div>

              <h3>{item.title}</h3>

              <h4>{item.value}</h4>

              <p>{item.description}</p>

              <button className="contact-btn">

                Contact Now

                <FaArrowRight />

              </button>

            </div>

          ))}
                  </div>

        {/* =====================================
            QUICK CONTACT BANNER
        ===================================== */}

        <div className="contact-banner">

          <div className="banner-content">

            <span className="section-tag">
              Need Immediate Assistance?
            </span>

            <h2>
              Our Support Team Is Available 24/7
            </h2>

            <p>
              Whether you need help with a booking,
              roadside assistance, or general inquiries,
              our dedicated customer support team is
              always ready to assist you anytime,
              anywhere.
            </p>

            <div className="banner-buttons">

              <button className="primary-btn">
                Call Now
              </button>

              <button className="secondary-btn">
                Chat on WhatsApp
              </button>

            </div>

          </div>

          <div className="banner-stats">

            <div className="stat-card">

              <h3>24/7</h3>

              <span>Customer Support</span>

            </div>

            <div className="stat-card">

              <h3>10K+</h3>

              <span>Happy Customers</span>

            </div>

            <div className="stat-card">

              <h3>15 Min</h3>

              <span>Average Response</span>

            </div>

            <div className="stat-card">

              <h3>99%</h3>

              <span>Support Satisfaction</span>

            </div>

          </div>

        </div>

      </div>

    </section>
  );
};

export default ContactInfo;