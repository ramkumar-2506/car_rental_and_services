import {
  FaMapMarkerAlt,
  FaPhoneAlt,
  FaClock,
  FaDirections,
} from "../Icons/FaFallback";



const GoogleMap = () => {
  return (
    <section className="google-map-section">

      <div className="google-map-container">

        <div className="map-header">

          <span className="section-tag">
            Find Us
          </span>

          <h2>
            Visit Our Office
          </h2>

          <p>
            Our office is conveniently located to serve
            customers with bookings, vehicle pickups,
            customer support, and corporate inquiries.
            Visit us during business hours or contact us
            anytime for assistance.
          </p>

        </div>

        <div className="map-wrapper">

          {/* Google Map */}

          <div className="map-frame">

            <iframe
              title="Car Rental Office Location"
              src="https://www.google.com/maps?q=Chennai,+Tamil+Nadu&output=embed"
              width="100%"
              height="100%"
              loading="lazy"
              allowFullScreen
            ></iframe>

          </div>

          {/* Office Details */}

          <div className="office-details">

            <h3>
              Head Office
            </h3>

            <div className="detail-item">

              <FaMapMarkerAlt />

              <div>

                <h4>Address</h4>

                <p>
                  123 Anna Salai,
                  Chennai,
                  Tamil Nadu - 600002
                </p>

              </div>

            </div>

            <div className="detail-item">

              <FaPhoneAlt />

              <div>

                <h4>Phone</h4>

                <p>+91 98765 43210</p>

              </div>

            </div>

            <div className="detail-item">

              <FaClock />

              <div>

                <h4>Working Hours</h4>

                <p>Monday - Sunday : 24 Hours</p>

              </div>

            </div>

            <button className="direction-btn">

              <FaDirections />

              Get Directions

            </button>

          </div>

        </div>

      </div>

    </section>
  );
};

export default GoogleMap;