import { useState } from "react";
import {
  FaUser,
  FaEnvelope,
  FaPhoneAlt,
  FaTag,
  FaCar,
  FaCalendarAlt,
  FaPaperPlane,
} from "../Icons/FaFallback";



const ContactForm = () => {

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    rentalType: "",
    pickupDate: "",
    message: "",
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    alert("Your message has been sent successfully!");

    setFormData({
      name: "",
      email: "",
      phone: "",
      subject: "",
      rentalType: "",
      pickupDate: "",
      message: "",
    });
  };

  return (
    <section className="contact-form-section">

      <div className="contact-form-container">

        <div className="form-header">

          <span className="section-tag">
            Get In Touch
          </span>

          <h2>
            Send Us A Message
          </h2>

          <p>
            Fill out the form below and our team will
            contact you as soon as possible regarding
            your booking, inquiry, or support request.
          </p>

        </div>

        <form
          className="contact-form"
          onSubmit={handleSubmit}
        >

          <div className="form-grid">

            <div className="input-group">

              <FaUser />

              <input
                type="text"
                name="name"
                placeholder="Full Name"
                value={formData.name}
                onChange={handleChange}
                required
              />

            </div>

            <div className="input-group">

              <FaEnvelope />

              <input
                type="email"
                name="email"
                placeholder="Email Address"
                value={formData.email}
                onChange={handleChange}
                required
              />

            </div>

            <div className="input-group">

              <FaPhoneAlt />

              <input
                type="tel"
                name="phone"
                placeholder="Phone Number"
                value={formData.phone}
                onChange={handleChange}
                required
              />

            </div>

            <div className="input-group">

              <FaTag />

              <input
                type="text"
                name="subject"
                placeholder="Subject"
                value={formData.subject}
                onChange={handleChange}
                required
              />

            </div>

            <div className="input-group">

              <FaCar />

              <select
                name="rentalType"
                value={formData.rentalType}
                onChange={handleChange}
                required
              >

                <option value="">
                  Select Rental Type
                </option>

                <option value="Self Drive">
                  Self Drive
                </option>

                <option value="With Driver">
                  With Driver
                </option>

                <option value="Corporate">
                  Corporate Rental
                </option>

                <option value="Long Term">
                  Long Term Lease
                </option>

              </select>

            </div>

            <div className="input-group">

              <FaCalendarAlt />

              <input
                type="date"
                name="pickupDate"
                value={formData.pickupDate}
                onChange={handleChange}
                required
              />

            </div>
                        <div className="textarea-group">

              <textarea
                name="message"
                placeholder="Write your message..."
                rows="6"
                value={formData.message}
                onChange={handleChange}
                required
              ></textarea>

            </div>

          </div>

          <button
            type="submit"
            className="submit-btn"
          >

            <FaPaperPlane />

            Send Message

          </button>

        </form>

        {/* =====================================
            CONTACT SUMMARY
        ===================================== */}

        <div className="contact-summary">

          <div className="summary-card">

            <h3>24/7</h3>

            <span>Customer Support</span>

          </div>

          <div className="summary-card">

            <h3>15 Min</h3>

            <span>Average Response Time</span>

          </div>

          <div className="summary-card">

            <h3>10K+</h3>

            <span>Happy Customers</span>

          </div>

          <div className="summary-card">

            <h3>99%</h3>

            <span>Customer Satisfaction</span>

          </div>

        </div>

      </div>

    </section>
  );
};

export default ContactForm;