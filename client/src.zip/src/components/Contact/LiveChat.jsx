import {
  FaComments,
  FaWhatsapp,
  FaPhoneAlt,
  FaEnvelope,
  FaHeadset,
  FaArrowRight,
} from "../Icons/FaFallback";



const supportOptions = [
  {
    id: 1,
    icon: <FaWhatsapp />,
    title: "WhatsApp Support",
    description:
      "Connect instantly with our support team through WhatsApp for bookings, rental inquiries, and quick assistance.",
    button: "Chat Now",
  },

  {
    id: 2,
    icon: <FaPhoneAlt />,
    title: "Call Support",
    description:
      "Speak directly with one of our customer care executives for immediate assistance and emergency support.",
    button: "Call Now",
  },

  {
    id: 3,
    icon: <FaEnvelope />,
    title: "Email Support",
    description:
      "Send us your questions, feedback, or business inquiries and we'll get back to you as soon as possible.",
    button: "Send Email",
  },
];

const LiveChat = () => {
  return (
    <section className="live-chat-section">

      <div className="live-chat-container">

        {/* ===========================
            HEADER
        =========================== */}

        <div className="chat-header">

          <span className="section-tag">
            Live Support
          </span>

          <h2>
            We're Always Ready To Help
          </h2>

          <p>
            Need immediate assistance? Our customer
            support team is available through multiple
            channels to ensure you receive quick and
            reliable help whenever you need it.
          </p>

        </div>

        {/* ===========================
            SUPPORT OPTIONS
        =========================== */}

        <div className="support-grid">

          {supportOptions.map((item) => (

            <div
              className="support-card"
              key={item.id}
            >

              <div className="support-icon">

                {item.icon}

              </div>

              <h3>{item.title}</h3>

              <p>{item.description}</p>

              <button className="support-btn">

                {item.button}

                <FaArrowRight />

              </button>

            </div>

          ))}

        </div>
                {/* ===========================
            LIVE CHAT CTA
        =========================== */}

        <div className="live-chat-cta">

          <div className="cta-content">

            <div className="cta-icon">

              <FaComments />

            </div>

            <span className="section-tag">
              24/7 Customer Assistance
            </span>

            <h2>
              Instant Support Whenever You Need It
            </h2>

            <p>
              Whether you need help with a booking,
              vehicle availability, payment issues,
              or roadside assistance, our dedicated
              support team is available around the
              clock to provide fast and reliable service.
            </p>

            <button className="chat-now-btn">

              Start Live Chat

              <FaArrowRight />

            </button>

          </div>

          <div className="chat-stats">

            <div className="chat-stat">

              <FaHeadset />

              <h3>24/7</h3>

              <span>Live Support</span>

            </div>

            <div className="chat-stat">

              <FaComments />

              <h3>15 Min</h3>

              <span>Average Response</span>

            </div>

            <div className="chat-stat">

              <FaWhatsapp />

              <h3>10K+</h3>

              <span>WhatsApp Chats</span>

            </div>

            <div className="chat-stat">

              <FaPhoneAlt />

              <h3>99%</h3>

              <span>Issue Resolution</span>

            </div>

          </div>

        </div>

      </div>

    </section>
  );
};

export default LiveChat;