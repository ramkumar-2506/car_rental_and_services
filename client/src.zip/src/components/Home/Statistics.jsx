import {
  FaCarSide,
  FaUsers,
  FaRoute,
  FaAward,
} from "react-icons/fa";

import "./Statistics.css";

const statistics = [
  {
    id: 1,
    icon: <FaCarSide />,
    number: "500+",
    title: "Premium Vehicles",
    description: "Luxury, SUV, Sedan & Economy Cars",
  },
  {
    id: 2,
    icon: <FaUsers />,
    number: "20K+",
    title: "Happy Customers",
    description: "Trusted by customers across India",
  },
  {
    id: 3,
    icon: <FaRoute />,
    number: "50K+",
    title: "Successful Trips",
    description: "Safe and memorable journeys completed",
  },
  {
    id: 4,
    icon: <FaAward />,
    number: "15+",
    title: "Years Experience",
    description: "Delivering premium rental services",
  },
];

const Statistics = () => {
  return (
    <section className="statistics">
      <div className="statistics-container">
        {statistics.map((item) => (
          <div className="stat-card" key={item.id}>
            <div className="stat-icon">
              {item.icon}
            </div>

            <h2>{item.number}</h2>

            <h4>{item.title}</h4>

            <p>{item.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Statistics;