
import testimonials from "../../data/testimonials";


const Testimonials = () => {
  return (
    <section className="whychoose-section home-section">
      <div className="whychoose-container home-inner home-homepad">
        <div className="whychoose-header">
          <span className="section-tag">Customer Reviews</span>
          <h2>What Our Customers Say</h2>
          <p>
            Real experiences from customers who trusted DriveEase with their rides.
          </p>
        </div>

        <div className="whychoose-grid">
          {testimonials?.slice?.(0, 6).map((t) => (
            <div key={t.name} className="why-card">
              <h3>{t.name}</h3>
              <p>{t.feedback || t.message || "Great service!"}</p>
              {t.rating ? (
                <div
                  style={{
                    marginTop: "14px",
                    fontWeight: 700,
                    color: "#facc15",
                  }}
                >
                  {t.rating} ★
                </div>
              ) : null}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;

