import { Link } from "react-router-dom";
import Button from "../Common/Button";



const CTA = () => {
  return (
    <section className="home-cta">
      <div className="home-cta-bg" aria-hidden="true" />

      <div className="home-cta-inner">
        <div className="home-cta-content">
          <div className="home-cta-text">
            <h2>Book in minutes. Drive in comfort.</h2>
            <p>
              Pick your car, choose your dates, and get an instant quote—no
              surprises.
            </p>
          </div>

          <div className="home-cta-actions">
            <Link to="/booking" aria-label="Book Now">
              <Button text="Book Now" variant="primary" />
            </Link>
            <Link to="/fleet" aria-label="Explore Fleet">
              <Button text="Explore Fleet" variant="outline" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTA;


