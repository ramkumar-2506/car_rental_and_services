


const WhyChooseUs = () => {
  return (
    <section className="whychoose-section home-section">
      <div className="whychoose-container home-inner">
        <div className="whychoose-header">
          <span className="section-tag">Why Choose Us</span>
          <h2>
            Experience The Difference With Our
            Premium Car Rental Services
          </h2>
          <p>
            We combine a modern fleet, transparent pricing, experienced
            professionals, and exceptional customer support to deliver a
            seamless travel experience every time.
          </p>
        </div>

        <div className="whychoose-grid">
          {[
            {
              title: "Premium Fleet",
              description:
                "Choose from luxury sedans, SUVs, hatchbacks, and premium vehicles that are regularly serviced and maintained.",
            },
            {
              title: "Transparent Pricing",
              description:
                "No hidden charges. Enjoy competitive prices with complete transparency from booking to vehicle return.",
            },
            {
              title: "Fully Insured Cars",
              description:
                "Every vehicle comes with comprehensive insurance coverage for a safe and worry-free journey.",
            },
          ].map((item) => (
            <div key={item.title} className="why-card">
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </div>
          ))}
        </div>

        <div className="why-extra">
          <div className="why-content">
            <span className="section-tag">Trusted By Thousands</span>
            <h2>Your Reliable Travel Partner For Every Journey</h2>
            <p>
              Whether you're planning a business trip, family vacation, airport
              transfer, or weekend getaway, we ensure every ride is comfortable,
              safe, and hassle-free with our premium rental services.
            </p>
            <ul>
              <li>✅ 100% Well-Maintained &amp; Sanitized Vehicles</li>
              <li>✅ Quick Pickup &amp; Easy Return Process</li>
              <li>✅ Affordable Daily, Weekly &amp; Monthly Rentals</li>
              <li>✅ 24/7 Customer Assistance &amp; Roadside Support</li>
            </ul>
          </div>

          <div className="why-image">
            <img
              src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80"
              alt="Car Rental Office"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;


