import {
  FaUsers,
  FaGasPump,
  FaCogs,
  FaStar,
  FaMapMarkerAlt,
  FaHeart,
} from "../Icons/FaFallback";
import { Link } from "react-router-dom";


const FleetCard = ({
  image,
  name,
  brand,
  category,
  fuel,
  transmission,
  seats,
  location,
  rating,
  reviews,
  price,
}) => {
  return (
    <div className="fleet-card">
      {/* Image */}

      <div className="fleet-image">
        <img src={image} alt={name} />

        <span className="fleet-category">
          {category}
        </span>

        <button className="wishlist-btn">
          <FaHeart />
        </button>
      </div>

      {/* Content */}

      <div className="fleet-content">
        <div className="fleet-header">
          <div>
            <h3>{name}</h3>
            <p>{brand}</p>
          </div>

          <div className="fleet-rating">
            <FaStar />
            <span>{rating}</span>
          </div>
        </div>

        <div className="fleet-location">
          <FaMapMarkerAlt />
          <span>{location}</span>
        </div>

        {/* Features */}

        <div className="fleet-features">
          <div>
            <FaGasPump />
            <span>{fuel}</span>
          </div>

          <div>
            <FaCogs />
            <span>{transmission}</span>
          </div>

          <div>
            <FaUsers />
            <span>{seats} Seats</span>
          </div>
        </div>

        <div className="fleet-footer">
          <div>
            <h2>
              ₹{price}
              <span>/day</span>
            </h2>

            <small>{reviews} Reviews</small>
          </div>

          <div className="fleet-buttons">
            <Link to="/car-details">
              <button className="details-btn">
                Details
              </button>
            </Link>

            <Link to="/booking">
              <button className="book-btn">
                Book Now
              </button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FleetCard;