import { useState } from "react";
import {
  FaStar,
  FaMapMarkerAlt,
  FaGasPump,
  FaCogs,
  FaUsers,
  FaSuitcase,
  FaSnowflake,
  FaHeart,
  FaCheckCircle,
  FaShieldAlt,
} from "react-icons/fa";
import { Link } from "react-router-dom";
import "./CarDetails.css";

const car = {
  name: "BMW 5 Series",
  brand: "BMW",
  category: "Luxury Sedan",
  location: "Chennai",
  rating: 4.9,
  reviews: 128,
  price: "8,500",

  fuel: "Petrol",
  transmission: "Automatic",
  seats: 5,
  luggage: 3,
  ac: "Automatic Climate Control",

  description:
    "The BMW 5 Series delivers the perfect balance of luxury, performance, and comfort. Designed for business executives and family trips alike, this premium sedan offers advanced technology, spacious interiors, and exceptional driving dynamics.",

  images: [
    "https://images.unsplash.com/photo-1555215695-3004980ad54e?auto=format&fit=crop&w=1200&q=80",

    "https://images.unsplash.com/photo-1502877338535-766e1452684a?auto=format&fit=crop&w=1200&q=80",

    "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=1200&q=80",

    "https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=1200&q=80",
  ],

  features: [
    "Bluetooth Connectivity",
    "Reverse Camera",
    "Apple CarPlay",
    "Android Auto",
    "GPS Navigation",
    "Leather Seats",
    "ABS",
    "Cruise Control",
    "Sunroof",
    "Airbags",
    "Parking Sensors",
    "USB Charging",
  ],
};

const CarDetails = () => {
  const [mainImage, setMainImage] = useState(car.images[0]);

  return (
    <section className="car-details">
      <div className="details-container">

        {/* Left Section */}

        <div className="details-left">

          {/* Main Image */}

          <div className="main-image">
            <img
              src={mainImage}
              alt={car.name}
            />

            <button className="wishlist-btn">
              <FaHeart />
            </button>
          </div>

          {/* Thumbnail Images */}

          <div className="thumbnail-grid">
            {car.images.map((image, index) => (
              <img
                key={index}
                src={image}
                alt={`Car ${index + 1}`}
                className={
                  mainImage === image ? "active" : ""
                }
                onClick={() => setMainImage(image)}
              />
            ))}
          </div>

          {/* Header */}

          <div className="car-header">

            <div>

              <span className="car-category">
                {car.category}
              </span>

              <h1>{car.name}</h1>

              <h4>{car.brand}</h4>

            </div>

            <div className="rating-box">
              <FaStar />
              <span>{car.rating}</span>
              <small>({car.reviews} Reviews)</small>
            </div>

          </div>

          {/* Location */}

          <div className="car-location">
            <FaMapMarkerAlt />
            <span>{car.location}</span>
          </div>

          {/* Specifications */}

          <div className="spec-grid">

            <div className="spec-card">
              <FaGasPump />
              <h5>Fuel</h5>
              <span>{car.fuel}</span>
            </div>

            <div className="spec-card">
              <FaCogs />
              <h5>Transmission</h5>
              <span>{car.transmission}</span>
            </div>

            <div className="spec-card">
              <FaUsers />
              <h5>Seats</h5>
              <span>{car.seats}</span>
            </div>

            <div className="spec-card">
              <FaSuitcase />
              <h5>Luggage</h5>
              <span>{car.luggage} Bags</span>
            </div>

            <div className="spec-card">
              <FaSnowflake />
              <h5>Air Conditioning</h5>
              <span>{car.ac}</span>
            </div>

          </div>
                    {/* Vehicle Overview */}

          <div className="overview-section">
            <h2>Vehicle Overview</h2>

            <p>{car.description}</p>
          </div>

          {/* Features */}

          <div className="features-section">
            <h2>Features & Amenities</h2>

            <div className="features-grid">
              {car.features.map((feature, index) => (
                <div
                  className="feature-item"
                  key={index}
                >
                  <FaCheckCircle />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Rental Includes */}

          <div className="includes-section">
            <h2>Rental Includes</h2>

            <div className="includes-grid">
              <div className="include-card">
                <FaShieldAlt />
                <div>
                  <h4>Basic Insurance</h4>
                  <p>Insurance coverage included with every rental.</p>
                </div>
              </div>

              <div className="include-card">
                <FaCheckCircle />
                <div>
                  <h4>24/7 Roadside Assistance</h4>
                  <p>Support whenever you need it during your trip.</p>
                </div>
              </div>

              <div className="include-card">
                <FaCheckCircle />
                <div>
                  <h4>Unlimited Kilometers</h4>
                  <p>Drive freely without worrying about mileage limits.</p>
                </div>
              </div>

              <div className="include-card">
                <FaCheckCircle />
                <div>
                  <h4>Free Cancellation</h4>
                  <p>Cancel your booking within the allowed period.</p>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Right Sidebar */}

        <div className="details-right">

          <div className="booking-card">

            <span className="price-label">
              Starting From
            </span>

            <h2>
              ₹{car.price}
              <span>/day</span>
            </h2>

            <ul>
              <li>✔ Premium Sanitized Vehicle</li>
              <li>✔ Instant Booking Confirmation</li>
              <li>✔ No Hidden Charges</li>
              <li>✔ 24/7 Customer Support</li>
            </ul>

            <Link to="/booking">
              <button className="book-now-btn">
                Book This Vehicle
              </button>
            </Link>

            <Link to="/contact">
              <button className="contact-btn">
                Contact Support
              </button>
            </Link>

          </div>

        </div>

      </div>
    </section>
  );
};

export default CarDetails;