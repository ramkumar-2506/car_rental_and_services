import { Link } from "react-router-dom";
import { FaArrowRight, FaCarSide } from "react-icons/fa";
import Button from "../Common/Button";
import "./FleetHero.css";

const heroImage =
  "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=1920&q=80";

const FleetHero = () => {
  return (
    <section
      className="fleet-hero"
      style={{
        backgroundImage: `url(${heroImage})`,
      }}
    >
      <div className="fleet-overlay"></div>

      <div className="fleet-container">
        <div className="fleet-content">
          <span className="fleet-subtitle">
            <FaCarSide />
            Premium Vehicle Collection
          </span>

          <h1>
            Explore Our
            <br />
            Premium Fleet
          </h1>

          <p>
            Choose from luxury sedans, premium SUVs, hatchbacks,
            electric vehicles, and executive cars. Every vehicle is
            professionally maintained, sanitized, and ready for your
            next journey.
          </p>

          <div className="fleet-buttons">
            <Link to="/booking">
              <Button
                text="Book Your Ride"
                variant="primary"
                icon={<FaArrowRight />}
              />
            </Link>

            <Link to="/contact">
              <Button
                text="Contact Us"
                variant="outline"
              />
            </Link>
          </div>

          <div className="fleet-badges">
            <div className="badge">
              <h3>500+</h3>
              <span>Cars Available</span>
            </div>

            <div className="badge">
              <h3>24/7</h3>
              <span>Customer Support</span>
            </div>

            <div className="badge">
              <h3>100%</h3>
              <span>Sanitized Vehicles</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FleetHero;